# Image credits and historical accuracy

The project downloads portraits from Wikimedia Commons at first launch. Exact author and license metadata is saved locally in `image_credits.json` when available. Please retain that file and follow each image's license if you publish or redistribute the project.

Planned Commons file pages:
- Salvador Dalí: https://commons.wikimedia.org/wiki/File:Salvador_Dali.jpg
- Fyodor Dostoevsky: https://commons.wikimedia.org/wiki/File:Dostoevskij_1872.jpg
- Bobby Fischer: https://commons.wikimedia.org/wiki/File:Bobby_Fischer_1966_portrait.jpg
- Abbas Mahmoud al-Aqqad: https://commons.wikimedia.org/wiki/File:Abbas_Mahmud_al-Aqqad.jpg
- Nikolai Gogol: https://commons.wikimedia.org/wiki/File:%D0%9D._%D0%92._%D0%93%D0%BE%D0%B3%D0%BE%D0%BB%D1%8C.png
- Sigmund Freud: https://commons.wikimedia.org/wiki/File:Freud_1885.jpg
- Elia Abu Madi: https://commons.wikimedia.org/wiki/File:Elia_Abu_Madi.jpg
- Ibn al-Haytham: https://commons.wikimedia.org/wiki/File:Ibn_Al-Haytham_portrait.jpg
- Al-Zahrawi: https://commons.wikimedia.org/wiki/File:Al-Zahrawi_Portrait.jpg
- Ibn Tufail: https://commons.wikimedia.org/wiki/File:Ibn_%E1%B9%ACufail,_Sayr_mulhimah_min_al-Sharq_wa-al-Gharb.png

Historical accuracy:
- The portraits of Ibn al-Haytham, Al-Zahrawi, and Ibn Tufail are artistic depictions created long after their lifetimes, not authentic photographs.
- Some modern portrait photographs may have specific reuse conditions. Check the downloaded metadata before publishing.
